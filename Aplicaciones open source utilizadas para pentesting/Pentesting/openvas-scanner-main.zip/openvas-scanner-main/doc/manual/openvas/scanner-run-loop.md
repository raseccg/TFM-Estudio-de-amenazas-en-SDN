# OpenVAS scanner run-loop

[Click to open scanner-run-loop](../../images/scanner_run_loop.svg)