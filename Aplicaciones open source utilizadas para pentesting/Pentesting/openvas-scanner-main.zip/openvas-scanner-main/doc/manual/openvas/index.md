# OpenVAS Scanner

## Overview

The OpenVAS Scanner is a scanner engine, which allows the user to scan networks.
