# Cert Functions

## GENERAL

Implementation of an API for X.509 certificates.

## TABLE OF CONTENT

- **[cert_close](cert_close.md)** - release a certificate object
- **[cert_open](cert_open.md)** - create a certificate object
- **[cert_query](cert_query.md)** - query a certificate object
