# Built-in plugins

## GENERAL

Here you can find complex built-in functions for NASL

## TABLE OF CONTENT

- **[plugin_run_find_service](plugin_run_find_service.md)** - openvas-scanner built-in find service
- **[plugin_run_openvas_tcp_scanner](plugin_run_openvas_tcp_scanner.md)** - openvas-scanner built-in port scanner
- **[plugin_run_synscan](plugin_run_synscan.md)** - performs a supposedly fast SYN port scan
