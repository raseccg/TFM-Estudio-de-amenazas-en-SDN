# script_copyright

**script_copyright** - Deprecated. Kept for backward compatibility, but currently does nothing.
