# get_host_ip

## NAME

**get_host_ip** - get the IP of the currently scanned host

## SYNOPSIS

*any* **get_host_ip**();

**get_host_ip** takes no argument.

## DESCRIPTION

Get the current host's ip

## RETURN VALUE

Return a string containing the host ip, FAKE_CELL on failure.
