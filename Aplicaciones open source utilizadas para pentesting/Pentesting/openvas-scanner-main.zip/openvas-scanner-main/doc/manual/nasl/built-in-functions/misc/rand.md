# rand

## NAME

**rand** - returns a pseudo random number.

## SYNOPSIS

*int* **rand**();

**rand** returns a pseudo random number.

## DESCRIPTION

Returns a pseudo random number.

## Returns

A pseudo random number.

## EXAMPLES

```cpp
display(rand());
```
