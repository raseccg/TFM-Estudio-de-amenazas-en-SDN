# scanner_status

## NAME

**scanner_status** - this function currently does nothing, kept for backwards compatibility
