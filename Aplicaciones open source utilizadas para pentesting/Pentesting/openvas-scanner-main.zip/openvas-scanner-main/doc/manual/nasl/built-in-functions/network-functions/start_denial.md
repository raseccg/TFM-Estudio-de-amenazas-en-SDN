# start_denial

## NAME

**start_denial** - initializes some internal data structure for end_denial

## SYNOPSIS

*void* **start_denial**();

**start_denial** takes no arguments.

## DESCRIPTION

Initializes some internal data structure for **[end_denial(3)](end_denial.md)**.

## RETURN VALUE

None

## SEE ALSO

**[end_denial(3)](end_denial.md)**