# plugin_run_synscan

## NAME

**plugin_run_synscan** - performs a supposedly fast SYN port scan

## SYNOPSIS

*NULL* **plugin_run_synscan**();

**plugin_run_synscan** takes no arguments.
