# Built-in Functions

## GENERAL

The NASL language contains a collection of built-in functions to provide many tools to detect vulnerabilities of a network device.