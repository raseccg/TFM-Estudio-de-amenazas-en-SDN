# vendor_version

## NAME

**vendor_version** - get vendor version

## SYNOPSIS

*string* **vendor_version**();

**vendor_version** takes no arguments

## DESCRIPTION

This function just returns the vendor version.

## RETURN VALUE

The vendor version.
