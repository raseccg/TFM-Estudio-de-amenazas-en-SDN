# insert_hexzeros

## NAME

**insert_hexzeros** - appends a empty byte to each character in a string

## SYNOPSIS

*str* **insert_hexzeros**(in: *string*);

**insert_hexzeros** takes 1 named argument.

## DESCRIPTION

This function takes a string and appends an empty byte to each character. Its argument is:
- in: the string to modify

## RETURN VALUE

The modified string.
