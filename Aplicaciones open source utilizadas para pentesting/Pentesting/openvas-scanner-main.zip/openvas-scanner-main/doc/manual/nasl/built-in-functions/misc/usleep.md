# usleep

## NAME

**usleep** - takes an integer and sleeps the amount of microseconds

## SYNOPSIS

*void* **usleep**(int);

**usleep** takes an integer and sleeps the amount of microseconds

## DESCRIPTION

usleeps the amount of given microseconds.

## EXAMPLES

```cpp
usleep(1);
```

## SEE ALSO

**[sleep(3)](sleep.md)**,
