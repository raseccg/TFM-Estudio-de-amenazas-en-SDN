# this_host_name

## NAME

**this_host_name** - get the host name of the current (attacking) machine

## SYNOPSIS

*any* **this_host_name**();

**this_host_name** takes no arguments

## DESCRIPTION

Get the host name of the current (attacking) machine.

## RETURN VALUE

The host name
