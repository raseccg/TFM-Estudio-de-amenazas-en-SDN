# get_script_oid

## NAME

**get_script_oid** - get the OID of the current script

## SYNOPSIS

*string* **get_script_oid**();

**get_script_oid** takes no arguments

## DESCRIPTION

THis function returns the OID of the current script.

## RETURN VALUE

OID of the current script
