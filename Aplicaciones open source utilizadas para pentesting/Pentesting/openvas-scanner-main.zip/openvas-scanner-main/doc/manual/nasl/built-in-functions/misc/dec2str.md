# dec2str

## NAME

**dec2str** - converts given num as str

## SYNOPSIS

*str* **dec2str**(num: int);

**dec2str** takes 1 named argument.

## DESCRIPTION

Converts a given number `num` to string.

## Returns

A string represenation of the given number.

## EXAMPLES

```cpp
display(dec2str(num: 23));
```
