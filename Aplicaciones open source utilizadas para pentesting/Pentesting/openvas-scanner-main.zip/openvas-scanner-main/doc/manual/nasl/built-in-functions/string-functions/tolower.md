# tolower

## NAME

**tolower** - converts a string to lower case

## SYNOPSIS

*string* **tolower**(0: *string);

**tolower** takes one positional argument.

## DESCRIPTION

This function converts any string to lower case.

The first positional argument is the *string* to convert.

## RETURN VALUE

The to lower case converted *string*.
