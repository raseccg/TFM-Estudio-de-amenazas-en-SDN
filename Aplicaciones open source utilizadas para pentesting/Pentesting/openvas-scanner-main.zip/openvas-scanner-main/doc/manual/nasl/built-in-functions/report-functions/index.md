# Report Functions

## GENERAL

Those functions are used for reporting (send data back to daemon).

## TABLE OF CONTENT

- **[error_message](error_message.md)** - Reports an error information.
- **[log_message](log_message.md)** - Reports a miscellaneous information.
- **[scanner_status](scanner_status.md)** - this function currently does nothing, kept for backwards compatibility
- **[security_message](security_message.md)** - Reports a severe flaw.
