# plugin_run_openvas_tcp_scanner

## NAME

**plugin_run_openvas_tcp_scanner** - openvas-scanner built-in port scanner

## SYNOPSIS

*NULL* **plugin_run_openvas_tcp_scanner**();

**plugin_run_openvas_tcp_scanner** takes no arguments.
