# islocalnet

## NAME

**islocalnet** - Check if the target host is on the same network as the attacking host

## SYNOPSIS

*any* **islocalnet**();

**islocalnet** takes no arguments

## DESCRIPTION

Check if the  target host is on the same network as the attacking host

## RETURN VALUE

Return True or False.
