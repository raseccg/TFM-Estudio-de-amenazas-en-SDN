# toupper

## NAME

**toupper** - converts a string to upper case

## SYNOPSIS

*string* **toupper**(0: *string);

**toupper** takes one positional argument.

## DESCRIPTION

This function converts any string to upper case.

The first positional argument is the *string* to convert.

## RETURN VALUE

The to upper case converted *string*.
