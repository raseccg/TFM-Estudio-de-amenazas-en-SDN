# this_host

## NAME

**this_host** - get the IP address of the current (attacking) machine

## SYNOPSIS

*any* **this_host**();

**this_host** takes no arguments

## DESCRIPTION

This function gets the IP address of the current (attacking) machine.

## RETURN VALUE

The IP address of the host target as string.
