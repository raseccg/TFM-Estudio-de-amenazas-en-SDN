# dump_ctxt

## NAME

**dump_ctxt** - debug function to print the keys available within the called context

## SYNOPSIS

*nil* **dump_ctxt**();

**dump_ctxt** takes no arguments.

## DESCRIPTION

Is a debug function to print the keys available within the called context. It does not take any nor returns any arguments.

## EXAMPLES

```cpp
dump_ctxt();
```
