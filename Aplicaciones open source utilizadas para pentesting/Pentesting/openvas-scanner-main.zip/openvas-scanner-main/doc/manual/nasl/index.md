# NASL Network Attack Scripting Language

## GENERAL

The Network Attack Scripting Language is a language, which is interpreted by the NASL interpreter, which is part of the OpenVAS Project. It is a simple language with focus on detecting vulnerability on network devices. Therefore it provides many built-in functions to attack hosts to discover vulnerabilities. A NASL script can be either run directly with the NASL interpreter [openvas-nasl](openvas-nasl.md) or within a scan with [openvas](../openvas/openvas.md).