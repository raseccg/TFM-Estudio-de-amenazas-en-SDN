The applications in this directory are templates and should be built using the onos-app module. 
