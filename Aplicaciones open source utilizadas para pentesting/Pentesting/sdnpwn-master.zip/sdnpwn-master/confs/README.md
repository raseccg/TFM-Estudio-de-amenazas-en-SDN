This configuration files are for use with the of-switch module.
